"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isBidi = exports.isServerStreaming = exports.isClientStreaming = exports.isUnary = exports.getRPCPath = exports.getRPCInputTypeExpr = exports.getRPCInputType = exports.getRPCOutputTypeExpr = exports.getRPCOutputType = exports.createParameter = void 0;
const ts = require("typescript");
const type = require("../type");
/**
 * Create typed parameter
 */
function createParameter(name, typename, optional = false) {
    return ts.factory.createParameterDeclaration(undefined, undefined, name, optional ? ts.factory.createToken(ts.SyntaxKind.QuestionToken) : undefined, typename);
}
exports.createParameter = createParameter;
function getRPCOutputType(rootDescriptor, methodDescriptor) {
    return type.getTypeReference(rootDescriptor, methodDescriptor.output_type);
}
exports.getRPCOutputType = getRPCOutputType;
function getRPCOutputTypeExpr(rootDescriptor, methodDescriptor) {
    return type.getTypeReferenceExpr(rootDescriptor, methodDescriptor.output_type);
}
exports.getRPCOutputTypeExpr = getRPCOutputTypeExpr;
function getRPCInputType(rootDescriptor, methodDescriptor) {
    return type.getTypeReference(rootDescriptor, methodDescriptor.input_type);
}
exports.getRPCInputType = getRPCInputType;
function getRPCInputTypeExpr(rootDescriptor, methodDescriptor) {
    return type.getTypeReferenceExpr(rootDescriptor, methodDescriptor.input_type);
}
exports.getRPCInputTypeExpr = getRPCInputTypeExpr;
function getRPCPath(rootDescriptor, serviceDescriptor, methodDescriptor) {
    let name = serviceDescriptor.name;
    if (rootDescriptor.package) {
        name = `${rootDescriptor.package}.${name}`;
    }
    return `/${name}/${methodDescriptor.name}`;
}
exports.getRPCPath = getRPCPath;
/**
 * @param {descriptor.MethodDescriptorProto} methodDescriptor
 * @returns {boolean}
 */
function isUnary(methodDescriptor) {
    return (methodDescriptor.client_streaming == false &&
        methodDescriptor.server_streaming == false);
}
exports.isUnary = isUnary;
function isClientStreaming(methodDescriptor) {
    return (methodDescriptor.client_streaming == true &&
        methodDescriptor.server_streaming == false);
}
exports.isClientStreaming = isClientStreaming;
function isServerStreaming(methodDescriptor) {
    return (methodDescriptor.client_streaming == false &&
        methodDescriptor.server_streaming == true);
}
exports.isServerStreaming = isServerStreaming;
function isBidi(methodDescriptor) {
    return (methodDescriptor.client_streaming == true &&
        methodDescriptor.server_streaming == true);
}
exports.isBidi = isBidi;
