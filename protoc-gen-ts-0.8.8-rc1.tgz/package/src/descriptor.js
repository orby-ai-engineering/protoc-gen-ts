"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.processDescriptorRecursively = exports.createNamespace = exports.createEnum = exports.initialize = void 0;
const field = require("./field");
const type = require("./type");
const ts = require("typescript");
const comment = require("./comment");
let config;
function initialize(configParameters) {
    config = configParameters;
}
exports.initialize = initialize;
function getFieldName(fieldDescriptor) {
    if (config.json_names) {
        return fieldDescriptor.json_name;
    }
    return fieldDescriptor.name;
}
function getPrefixedFieldName(prefix, fieldDescriptor) {
    const fieldName = getFieldName(fieldDescriptor);
    if (prefix.length == 0 || fieldName.length == 0) {
        return fieldName;
    }
    return config.json_names
        ? `${prefix}${fieldName.charAt(0).toUpperCase()}${fieldName.slice(1)}`
        : `${prefix}_${fieldName}`;
}
/**
 * Returns a enum for the enum descriptor
 */
function createEnum(enumDescriptor, parentName = '') {
    const values = [];
    for (const valueDescriptor of enumDescriptor.value) {
        values.push(comment.addDeprecatedJsDoc(ts.factory.createEnumMember(valueDescriptor.name, ts.factory.createNumericLiteral(valueDescriptor.number)), valueDescriptor.options?.deprecated));
    }
    return comment.addDeprecatedJsDoc(ts.factory.createEnumDeclaration([ts.factory.createModifier(ts.SyntaxKind.ExportKeyword)], ts.factory.createIdentifier(`${parentName}${enumDescriptor.name}`), values), enumDescriptor.options?.deprecated);
}
exports.createEnum = createEnum;
function createFromObject(rootDescriptor, messageDescriptor, parentName = '') {
    const dataIdentifier = ts.factory.createIdentifier("data");
    const messageIdentifier = ts.factory.createIdentifier("message");
    const statements = [];
    const properties = [];
    for (const fieldDescriptor of messageDescriptor.field) {
        let assignmentExpr = ts.factory.createPropertyAccessExpression(dataIdentifier, getFieldName(fieldDescriptor));
        if (field.isMap(fieldDescriptor)) {
            const [keyDescriptor, valueDescriptor] = type.getMapDescriptor(fieldDescriptor.type_name).field;
            assignmentExpr = ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("Object"), "entries"), undefined, [assignmentExpr]);
            let coercer;
            if (field.isNumber(keyDescriptor)) {
                coercer = "Number";
            }
            else if (field.isBoolean(keyDescriptor)) {
                coercer = "Boolean";
            }
            if (field.isMessage(valueDescriptor) || !field.isString(keyDescriptor)) {
                let keyExpr = ts.factory.createIdentifier("key");
                let valueExpr = ts.factory.createIdentifier("value");
                if (coercer) {
                    keyExpr = ts.factory.createCallExpression(ts.factory.createIdentifier(coercer), undefined, [keyExpr]);
                }
                if (field.isMessage(valueDescriptor)) {
                    valueExpr = ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(type.getTypeReferenceExpr(rootDescriptor, valueDescriptor.type_name), "fromObject"), undefined, [ts.factory.createIdentifier("value")]);
                }
                assignmentExpr = ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(assignmentExpr, "map"), undefined, [
                    ts.factory.createArrowFunction(undefined, undefined, [
                        ts.factory.createParameterDeclaration(undefined, undefined, ts.factory.createArrayBindingPattern([
                            ts.factory.createBindingElement(undefined, undefined, "key"),
                            ts.factory.createBindingElement(undefined, undefined, "value"),
                        ])),
                    ], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createArrayLiteralExpression([keyExpr, valueExpr])),
                ]);
            }
            assignmentExpr = ts.factory.createNewExpression(ts.factory.createIdentifier("Map"), undefined, [assignmentExpr]);
        }
        else if (field.isMessage(fieldDescriptor)) {
            if (field.isRepeated(fieldDescriptor)) {
                const arrowFunc = ts.factory.createArrowFunction(undefined, undefined, [
                    ts.factory.createParameterDeclaration(undefined, undefined, "item"),
                ], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(type.getTypeReferenceExpr(rootDescriptor, fieldDescriptor.type_name), "fromObject"), undefined, [ts.factory.createIdentifier("item")]));
                assignmentExpr = ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(assignmentExpr, "map"), undefined, [arrowFunc]);
            }
            else {
                assignmentExpr = ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(type.getTypeReferenceExpr(rootDescriptor, fieldDescriptor.type_name), "fromObject"), undefined, [
                    ts.factory.createPropertyAccessExpression(dataIdentifier, getFieldName(fieldDescriptor)),
                ]);
            }
        }
        if (field.isOptional(rootDescriptor, fieldDescriptor)) {
            const propertyAccessor = ts.factory.createPropertyAccessExpression(dataIdentifier, getFieldName(fieldDescriptor));
            let condition = ts.factory.createBinaryExpression(propertyAccessor, ts.factory.createToken(ts.SyntaxKind.ExclamationEqualsToken), ts.factory.createNull());
            if (field.isMap(fieldDescriptor)) {
                condition = ts.factory.createBinaryExpression(ts.factory.createTypeOfExpression(propertyAccessor), ts.factory.createToken(ts.SyntaxKind.EqualsEqualsToken), ts.factory.createStringLiteral("object"));
            }
            statements.push(ts.factory.createIfStatement(condition, ts.factory.createBlock([
                ts.factory.createExpressionStatement(ts.factory.createBinaryExpression(ts.factory.createPropertyAccessExpression(messageIdentifier, getFieldName(fieldDescriptor)), ts.factory.createToken(ts.SyntaxKind.EqualsToken), assignmentExpr)),
            ], true)));
        }
        else {
            properties.push(ts.factory.createPropertyAssignment(getFieldName(fieldDescriptor), assignmentExpr));
        }
    }
    statements.unshift(ts.factory.createVariableStatement(undefined, ts.factory.createVariableDeclarationList([
        ts.factory.createVariableDeclaration("message", undefined, undefined, ts.factory.createNewExpression(ts.factory.createIdentifier(`${parentName}${messageDescriptor.name}`), undefined, [ts.factory.createObjectLiteralExpression(properties, true)])),
    ], ts.NodeFlags.Const)));
    statements.push(ts.factory.createReturnStatement(messageIdentifier));
    return ts.factory.createMethodDeclaration([ts.factory.createModifier(ts.SyntaxKind.StaticKeyword)], undefined, ts.factory.createIdentifier("fromObject"), undefined, undefined, [
        ts.factory.createParameterDeclaration(undefined, undefined, dataIdentifier, undefined, createPrimitiveMessageSignature(rootDescriptor, messageDescriptor)),
    ], ts.factory.createTypeReferenceNode(ts.factory.createIdentifier(`${parentName}${messageDescriptor.name}`), undefined), ts.factory.createBlock(statements, true));
}
function createToObject(rootDescriptor, messageDescriptor) {
    const statements = [];
    const properties = [];
    const dataIdentifier = ts.factory.createIdentifier("data");
    for (const fieldDescriptor of messageDescriptor.field) {
        let valueExpr = ts.factory.createPropertyAccessExpression(ts.factory.createThis(), getFieldName(fieldDescriptor));
        if (field.isMap(fieldDescriptor)) {
            const [, valueDescriptor] = type.getMapDescriptor(fieldDescriptor.type_name).field;
            if (field.isMessage(valueDescriptor)) {
                valueExpr = ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createCallExpression(ts.factory.createPropertyAccessChain(ts.factory.createIdentifier("Array"), undefined, "from"), undefined, [valueExpr]), "map"), undefined, [
                    ts.factory.createArrowFunction(undefined, undefined, [
                        ts.factory.createParameterDeclaration(undefined, undefined, ts.factory.createArrayBindingPattern([
                            ts.factory.createBindingElement(undefined, undefined, "key"),
                            ts.factory.createBindingElement(undefined, undefined, "value"),
                        ])),
                    ], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createArrayLiteralExpression([
                        ts.factory.createIdentifier("key"),
                        ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("value"), "toObject"), undefined, []),
                    ])),
                ]);
            }
            valueExpr = ts.factory.createCallExpression(ts.factory.createPropertyAccessChain(ts.factory.createIdentifier("Object"), undefined, "fromEntries"), undefined, [valueExpr]);
        }
        else if (field.isMessage(fieldDescriptor)) {
            if (field.isRepeated(fieldDescriptor)) {
                const arrowFunc = ts.factory.createArrowFunction(undefined, undefined, [
                    ts.factory.createParameterDeclaration(undefined, undefined, "item", undefined, type.getTypeReference(rootDescriptor, fieldDescriptor.type_name)),
                ], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("item"), "toObject"), undefined, undefined));
                valueExpr = ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(valueExpr, "map"), undefined, [arrowFunc]);
            }
            else {
                valueExpr = ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(valueExpr, "toObject"), undefined, undefined);
            }
        }
        if (field.isOptional(rootDescriptor, fieldDescriptor) ||
            field.isMessage(fieldDescriptor) ||
            field.isRequiredWithoutExplicitDefault(rootDescriptor, fieldDescriptor)) {
            const propertyAccessor = ts.factory.createPropertyAccessExpression(ts.factory.createThis(), getFieldName(fieldDescriptor));
            let condition = ts.factory.createBinaryExpression(propertyAccessor, ts.factory.createToken(ts.SyntaxKind.ExclamationEqualsToken), ts.factory.createNull());
            statements.push(ts.factory.createIfStatement(condition, ts.factory.createBlock([
                ts.factory.createExpressionStatement(ts.factory.createBinaryExpression(ts.factory.createPropertyAccessExpression(dataIdentifier, getFieldName(fieldDescriptor)), ts.factory.createToken(ts.SyntaxKind.EqualsToken), valueExpr)),
            ], true)));
        }
        else {
            properties.push(ts.factory.createPropertyAssignment(getFieldName(fieldDescriptor), valueExpr));
        }
    }
    statements.unshift(ts.factory.createVariableStatement(undefined, ts.factory.createVariableDeclarationList([
        ts.factory.createVariableDeclaration("data", undefined, createPrimitiveMessageSignature(rootDescriptor, messageDescriptor), ts.factory.createObjectLiteralExpression(properties, true)),
    ], ts.NodeFlags.Const)));
    statements.push(ts.factory.createReturnStatement(dataIdentifier));
    return ts.factory.createMethodDeclaration(undefined, undefined, ts.factory.createIdentifier("toObject"), undefined, undefined, [], undefined, ts.factory.createBlock(statements, true));
}
function createNamespace(parentName, statements) {
    const identifiers = String(parentName).split(".");
    console.log(identifiers);
    let decl = ts.factory.createModuleBlock(statements);
    for (let i = identifiers.length - 1; i >= 0; i--) {
        decl = ts.factory.createModuleDeclaration([ts.factory.createModifier(ts.SyntaxKind.ExportKeyword)], ts.factory.createIdentifier(identifiers[i]), decl, ts.NodeFlags.Namespace);
    }
    return decl;
}
exports.createNamespace = createNamespace;
function createMessageSignature(rootDescriptor, messageDescriptor, parentName = '') {
    const oneOfSignatures = [];
    for (const [index] of messageDescriptor.oneof_decl.entries()) {
        const childSignatures = [];
        for (const currentFieldDescriptor of messageDescriptor.field) {
            if (!currentFieldDescriptor.has_oneof_index || currentFieldDescriptor.oneof_index !== index) {
                continue;
            }
            const members = [];
            for (const fieldDescriptor of messageDescriptor.field) {
                if (!fieldDescriptor.has_oneof_index || fieldDescriptor.oneof_index != index) {
                    continue;
                }
                let fieldType = ts.factory.createTypeReferenceNode("never");
                if (fieldDescriptor == currentFieldDescriptor) {
                    fieldType = field.wrapRepeatedType(field.getType(fieldDescriptor, rootDescriptor), fieldDescriptor);
                }
                members.push(comment.addDeprecatedJsDoc(ts.factory.createPropertySignature(undefined, getFieldName(fieldDescriptor), ts.factory.createToken(ts.SyntaxKind.QuestionToken), fieldType), fieldDescriptor.options?.deprecated &&
                    fieldDescriptor == currentFieldDescriptor));
            }
            childSignatures.push(ts.factory.createTypeLiteralNode(members));
        }
        oneOfSignatures.push(ts.factory.createUnionTypeNode(childSignatures));
    }
    const fieldSignatures = [];
    for (const fieldDescriptor of messageDescriptor.field) {
        if (!fieldDescriptor.has_oneof_index) {
            fieldSignatures.push(comment.addDeprecatedJsDoc(ts.factory.createPropertySignature(undefined, getFieldName(fieldDescriptor), field.isOptional(rootDescriptor, fieldDescriptor)
                ? ts.factory.createToken(ts.SyntaxKind.QuestionToken)
                : undefined, field.wrapRepeatedType(field.getType(fieldDescriptor, rootDescriptor), fieldDescriptor)), fieldDescriptor.options?.deprecated));
        }
    }
    if (oneOfSignatures.length) {
        return ts.factory.createIntersectionTypeNode([
            ts.factory.createTypeLiteralNode(fieldSignatures),
            ts.factory.createUnionTypeNode(oneOfSignatures),
        ]);
    }
    return ts.factory.createTypeLiteralNode(fieldSignatures);
}
function createPrimitiveMessageSignature(rootDescriptor, messageDescriptor) {
    const fieldSignatures = [];
    const wrapMessageType = (fieldType) => {
        const type = ts.factory.createTypeQueryNode(ts.factory.createQualifiedName(ts.factory.createQualifiedName(fieldType.typeName, "prototype"), "toObject"));
        return ts.factory.createTypeReferenceNode("ReturnType", [type]);
    };
    for (const fieldDescriptor of messageDescriptor.field) {
        let fieldType = field.getType(fieldDescriptor, rootDescriptor);
        if (field.isMap(fieldDescriptor)) {
            const [keyDescriptor, valueDescriptor] = type.getMapDescriptor(fieldDescriptor.type_name).field;
            let valueType = field.getType(valueDescriptor, rootDescriptor);
            if (field.isMessage(valueDescriptor)) {
                valueType = wrapMessageType(valueType);
            }
            fieldType = ts.factory.createTypeLiteralNode([
                ts.factory.createIndexSignature(undefined, [
                    ts.factory.createParameterDeclaration(undefined, undefined, "key", undefined, field.getType(keyDescriptor, rootDescriptor)),
                ], valueType),
            ]);
        }
        else if (field.isMessage(fieldDescriptor)) {
            fieldType = wrapMessageType(fieldType);
        }
        fieldSignatures.push(ts.factory.createPropertySignature(undefined, getFieldName(fieldDescriptor), (field.isOptional(rootDescriptor, fieldDescriptor) ||
            field.isMessage(fieldDescriptor) ||
            field.isRequiredWithoutExplicitDefault(rootDescriptor, fieldDescriptor))
            ? ts.factory.createToken(ts.SyntaxKind.QuestionToken)
            : undefined, field.wrapRepeatedType(fieldType, fieldDescriptor)));
    }
    return ts.factory.createTypeLiteralNode(fieldSignatures);
}
function getPivot(descriptor) {
    const kDefaultPivot = 500;
    let max_field_number = 0;
    for (const field of descriptor.field) {
        if (field.extendee && field.number > max_field_number) {
            max_field_number = 0;
        }
    }
    let pivot = -1;
    if (descriptor.extension_range.length && max_field_number >= kDefaultPivot) {
        pivot =
            max_field_number + 1 < kDefaultPivot
                ? max_field_number + 1
                : kDefaultPivot;
    }
    return pivot;
}
/**
 *
 * @param {descriptor.FileDescriptorProto} rootDescriptor
 * @param {descriptor.DescriptorProto} messageDescriptor
 * @param {string} pbIdentifier
 */
function createConstructor(rootDescriptor, messageDescriptor, pbIdentifier, parentName = '') {
    const dataIdentifier = ts.factory.createIdentifier("data");
    const typeNode = ts.factory.createUnionTypeNode([
        ts.factory.createArrayTypeNode(ts.factory.createTypeReferenceNode(ts.factory.createIdentifier("any"), undefined)),
        createMessageSignature(rootDescriptor, messageDescriptor, parentName),
    ]);
    // Get repeated fields numbers
    const repeatedFields = messageDescriptor.field
        .filter((fd) => field.isRepeated(fd) && !field.isMap(fd))
        .map((fd) => ts.factory.createNumericLiteral(fd.number));
    const statements = [
        // Create super(); statement
        ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createSuper(), undefined, undefined)),
        // Create initialize(); statement
        ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "Message"), "initialize"), undefined, [
            ts.factory.createThis(),
            ts.factory.createConditionalExpression(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("Array"), "isArray"), undefined, [dataIdentifier]), ts.factory.createToken(ts.SyntaxKind.QuestionToken), dataIdentifier, ts.factory.createToken(ts.SyntaxKind.ColonToken), ts.factory.createArrayLiteralExpression()),
            ts.factory.createNumericLiteral(0),
            ts.factory.createNumericLiteral(getPivot(messageDescriptor)),
            ts.factory.createArrayLiteralExpression(repeatedFields),
            ts.factory.createPropertyAccessExpression(ts.factory.createThis(), ts.factory.createPrivateIdentifier("#one_of_decls")),
        ])),
        // Create data variable and if block
        ts.factory.createIfStatement(ts.factory.createBinaryExpression(ts.factory.createLogicalNot(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("Array"), "isArray"), undefined, [dataIdentifier])), ts.SyntaxKind.AmpersandAmpersandToken, ts.factory.createBinaryExpression(ts.factory.createTypeOfExpression(dataIdentifier), ts.SyntaxKind.EqualsEqualsToken, ts.factory.createStringLiteral("object"))), ts.factory.createBlock(messageDescriptor.field.map((fieldDescriptor) => {
            const assigmentExpression = ts.factory.createExpressionStatement(ts.factory.createBinaryExpression(ts.factory.createPropertyAccessExpression(ts.factory.createThis(), getFieldName(fieldDescriptor)), ts.SyntaxKind.EqualsToken, ts.factory.createPropertyAccessExpression(dataIdentifier, getFieldName(fieldDescriptor))));
            if (!field.isOptional(rootDescriptor, fieldDescriptor)) {
                return assigmentExpression;
            }
            return ts.factory.createIfStatement(ts.factory.createBinaryExpression(ts.factory.createBinaryExpression(ts.factory.createStringLiteral(getFieldName(fieldDescriptor)), ts.factory.createToken(ts.SyntaxKind.InKeyword), dataIdentifier), ts.factory.createToken(ts.SyntaxKind.AmpersandAmpersandToken), ts.factory.createBinaryExpression(ts.factory.createPropertyAccessExpression(dataIdentifier, getFieldName(fieldDescriptor)), ts.factory.createToken(ts.SyntaxKind.ExclamationEqualsToken), ts.factory.createIdentifier("undefined"))), ts.factory.createBlock([assigmentExpression], true));
        }))),
        ...messageDescriptor.field
            .filter((fieldDescriptor) => field.isMap(fieldDescriptor))
            .map((fieldDescriptor) => {
            const propertyAccessor = ts.factory.createPropertyAccessExpression(ts.factory.createThis(), getFieldName(fieldDescriptor));
            return ts.factory.createIfStatement(ts.factory.createPrefixUnaryExpression(ts.SyntaxKind.ExclamationToken, propertyAccessor), ts.factory.createExpressionStatement(ts.factory.createBinaryExpression(propertyAccessor, ts.factory.createToken(ts.SyntaxKind.EqualsToken), ts.factory.createNewExpression(ts.factory.createIdentifier("Map"), undefined, []))));
        }),
    ];
    return ts.factory.createConstructorDeclaration(undefined, [
        ts.factory.createParameterDeclaration(undefined, undefined, dataIdentifier, ts.factory.createToken(ts.SyntaxKind.QuestionToken), typeNode),
    ], ts.factory.createBlock(statements, true));
}
/**
 * Returns a get accessor for the field
 */
function createGetter(rootDescriptor, fieldDescriptor, pbIdentifier, parentName = '') {
    const getterType = field.wrapRepeatedType(field.getType(fieldDescriptor, rootDescriptor), fieldDescriptor);
    let getterExpr = createGetterCall(rootDescriptor, fieldDescriptor, pbIdentifier, parentName);
    if (field.isMap(fieldDescriptor)) {
        getterExpr = ts.factory.createAsExpression(getterExpr, ts.factory.createToken(ts.SyntaxKind.AnyKeyword));
    }
    return comment.addDeprecatedJsDoc(ts.factory.createGetAccessorDeclaration(undefined, getFieldName(fieldDescriptor), [], undefined, ts.factory.createBlock([
        ts.factory.createReturnStatement(ts.factory.createAsExpression(getterExpr, getterType)),
    ], true)), fieldDescriptor.options?.deprecated);
}
function createGetterCall(rootDescriptor, fieldDescriptor, pbIdentifier, parentName = '') {
    let args;
    let getterMethod = "getField";
    if (field.isMessage(fieldDescriptor) && !field.isMap(fieldDescriptor)) {
        getterMethod = field.isRepeated(fieldDescriptor)
            ? "getRepeatedWrapperField"
            : "getWrapperField";
        args = [
            ts.factory.createThis(),
            type.getTypeReferenceExpr(rootDescriptor, fieldDescriptor.type_name),
            ts.factory.createNumericLiteral(fieldDescriptor.number),
        ];
    }
    else if (field.isMap(fieldDescriptor) ||
        field.isRequiredWithoutExplicitDefault(rootDescriptor, fieldDescriptor)) {
        getterMethod = "getField";
        args = [
            ts.factory.createThis(),
            ts.factory.createNumericLiteral(fieldDescriptor.number),
        ];
    }
    else {
        args = [
            ts.factory.createThis(),
            ts.factory.createNumericLiteral(fieldDescriptor.number),
        ];
        getterMethod = "getFieldWithDefault";
        let _default;
        if (field.isRepeated(fieldDescriptor)) {
            _default = fieldDescriptor.has_default_value
                ? ts.factory.createIdentifier(fieldDescriptor.default_value)
                : ts.factory.createArrayLiteralExpression([], false);
        }
        else if (field.isEnum(fieldDescriptor)) {
            _default = ts.factory.createPropertyAccessExpression(type.getTypeReferenceExpr(rootDescriptor, fieldDescriptor.type_name), fieldDescriptor.has_default_value
                ? fieldDescriptor.default_value
                : type.getLeadingEnumMember(fieldDescriptor.type_name));
        }
        else if (field.isBytes(fieldDescriptor)) {
            _default = fieldDescriptor.has_default_value
                ? ts.factory.createIdentifier(fieldDescriptor.default_value)
                : ts.factory.createNewExpression(ts.factory.createIdentifier("Uint8Array"), undefined, [ts.factory.createNumericLiteral("0")]);
        }
        else if (field.isString(fieldDescriptor) || field.hasJsTypeString(fieldDescriptor)) {
            _default = fieldDescriptor.has_default_value
                ? ts.factory.createStringLiteral(fieldDescriptor.default_value)
                : ts.factory.createStringLiteral(field.hasJsTypeString(fieldDescriptor) ? "0" : "");
        }
        else if (field.isBoolean(fieldDescriptor)) {
            _default = fieldDescriptor.has_default_value
                ? ts.factory.createIdentifier(fieldDescriptor.default_value)
                : ts.factory.createFalse();
        }
        else {
            _default = fieldDescriptor.has_default_value
                ? ts.factory.createIdentifier(fieldDescriptor.default_value)
                : ts.factory.createNumericLiteral(0);
        }
        args.push(_default);
    }
    return ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "Message"), ts.factory.createIdentifier(getterMethod)), undefined, args);
}
/**
 * Returns a class for the message descriptor
 */
function createOneOfGetter(index, oneofDescriptor, messageDescriptor, pbIdentifier) {
    const numbers = [];
    const types = [
        ts.factory.createLiteralTypeNode(ts.factory.createStringLiteral("none")),
    ];
    const cases = [
        ts.factory.createPropertyAssignment(ts.factory.createNumericLiteral(0), ts.factory.createStringLiteral("none")),
    ];
    for (const field of messageDescriptor.field) {
        if (!field.has_oneof_index || field.oneof_index !== index) {
            continue;
        }
        numbers.push(ts.factory.createNumericLiteral(field.number));
        types.push(ts.factory.createLiteralTypeNode(ts.factory.createStringLiteral(getFieldName(field))));
        cases.push(ts.factory.createPropertyAssignment(ts.factory.createNumericLiteral(field.number), ts.factory.createStringLiteral(getFieldName(field))));
    }
    const statements = [
        ts.factory.createVariableStatement(undefined, ts.factory.createVariableDeclarationList([
            ts.factory.createVariableDeclaration("cases", undefined, ts.factory.createTypeLiteralNode([
                ts.factory.createIndexSignature(undefined, [
                    ts.factory.createParameterDeclaration(undefined, undefined, "index", undefined, ts.factory.createKeywordTypeNode(ts.SyntaxKind.NumberKeyword)),
                ], ts.factory.createUnionTypeNode(types)),
            ]), ts.factory.createObjectLiteralExpression(cases, true)),
        ], ts.NodeFlags.Const)),
        ts.factory.createReturnStatement(ts.factory.createElementAccessExpression(ts.factory.createIdentifier("cases"), ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "Message"), ts.factory.createIdentifier("computeOneofCase")), undefined, [
            ts.factory.createThis(),
            ts.factory.createArrayLiteralExpression(numbers),
        ]))),
    ];
    return ts.factory.createGetAccessorDeclaration(undefined, oneofDescriptor.name, [], undefined, ts.factory.createBlock(statements, true));
}
function createSetter(rootDescriptor, messageDescriptor, fieldDescriptor, pbIdentifier) {
    const type = field.wrapRepeatedType(field.getType(fieldDescriptor, rootDescriptor), fieldDescriptor);
    const valueParameter = ts.factory.createIdentifier("value");
    let block;
    if (fieldDescriptor.has_oneof_index) {
        block = createOneOfSetterBlock(fieldDescriptor, valueParameter, pbIdentifier);
    }
    else {
        block = createSetterBlock(fieldDescriptor, valueParameter, pbIdentifier);
    }
    return comment.addDeprecatedJsDoc(ts.factory.createSetAccessorDeclaration(undefined, getFieldName(fieldDescriptor), [
        ts.factory.createParameterDeclaration(undefined, undefined, valueParameter, undefined, type),
    ], block), fieldDescriptor.options?.deprecated);
}
function createOneOfSetterBlock(fieldDescriptor, valueParameter, pbIdentifier) {
    const method = field.isMessage(fieldDescriptor)
        ? "setOneofWrapperField"
        : "setOneofField";
    return ts.factory.createBlock([
        ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "Message"), method), undefined, [
            ts.factory.createThis(),
            ts.factory.createNumericLiteral(fieldDescriptor.number),
            ts.factory.createElementAccessExpression(ts.factory.createPropertyAccessExpression(ts.factory.createThis(), ts.factory.createPrivateIdentifier("#one_of_decls")), fieldDescriptor.has_oneof_index ? fieldDescriptor.oneof_index : undefined),
            valueParameter,
        ])),
    ], true);
}
function createSetterBlock(fieldDescriptor, valueParameter, pbIdentifier) {
    const method = field.isMessage(fieldDescriptor) && !field.isMap(fieldDescriptor)
        ? field.isRepeated(fieldDescriptor)
            ? "setRepeatedWrapperField"
            : "setWrapperField"
        : "setField";
    const parameter = field.isMap(fieldDescriptor)
        ? ts.factory.createAsExpression(valueParameter, ts.factory.createToken(ts.SyntaxKind.AnyKeyword))
        : valueParameter;
    return ts.factory.createBlock([
        ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "Message"), method), undefined, [
            ts.factory.createThis(),
            ts.factory.createNumericLiteral(fieldDescriptor.number),
            parameter,
        ])),
    ], true);
}
/**
 * Returns a presence has method for the field
 */
function createPresenceHas(fieldDescriptor, pbIdentifier) {
    return comment.addDeprecatedJsDoc(ts.factory.createGetAccessorDeclaration(undefined, getPrefixedFieldName("has", fieldDescriptor), [], undefined, createPresenceHasBlock(fieldDescriptor, pbIdentifier)), fieldDescriptor.options?.deprecated);
}
function createPresenceHasBlock(fieldDescriptor, pbIdentifier) {
    return ts.factory.createBlock([
        ts.factory.createReturnStatement(ts.factory.createBinaryExpression(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, ts.factory.createIdentifier("Message")), ts.factory.createIdentifier("getField")), undefined, [
            ts.factory.createThis(),
            ts.factory.createNumericLiteral(fieldDescriptor.number),
        ]), ts.factory.createToken(ts.SyntaxKind.ExclamationEqualsToken), ts.factory.createNull())),
    ], true);
}
/**
 * Returns the serialize method for the message class
 */
function createSerialize(rootDescriptor, messageDescriptor, pbIdentifier) {
    const statements = [
        ts.factory.createVariableStatement(undefined, ts.factory.createVariableDeclarationList([
            ts.factory.createVariableDeclaration("writer", undefined, undefined, ts.factory.createBinaryExpression(ts.factory.createIdentifier("w"), ts.SyntaxKind.BarBarToken, ts.factory.createNewExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "BinaryWriter"), undefined, []))),
        ], ts.NodeFlags.Const)),
    ];
    for (const fieldDescriptor of messageDescriptor.field) {
        const propAccessor = ts.factory.createPropertyAccessExpression(ts.factory.createThis(), getFieldName(fieldDescriptor));
        const hasFieldCondition = field.hasPresenceGetter(rootDescriptor, fieldDescriptor)
            ? ts.factory.createPropertyAccessExpression(ts.factory.createThis(), getPrefixedFieldName("has", fieldDescriptor))
            : undefined;
        if (field.isMap(fieldDescriptor)) {
            const [keyDescriptor, valueDescriptor] = type.getMapDescriptor(fieldDescriptor.type_name).field;
            const valueExprArgs = [
                ts.factory.createNumericLiteral(2),
                ts.factory.createIdentifier("value"),
            ];
            if (field.isMessage(valueDescriptor)) {
                valueExprArgs.push(ts.factory.createArrowFunction(undefined, undefined, [], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("value"), "serialize"), undefined, [ts.factory.createIdentifier("writer")])));
            }
            const writeCall = ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("writer"), "writeMessage"), undefined, [
                ts.factory.createNumericLiteral(fieldDescriptor.number),
                propAccessor,
                ts.factory.createArrowFunction(undefined, undefined, [], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createBlock([
                    ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("writer"), ts.factory.createIdentifier(`write${field.toBinaryMethodName(keyDescriptor, rootDescriptor)}`)), undefined, [
                        ts.factory.createNumericLiteral(1),
                        ts.factory.createIdentifier("key"),
                    ])),
                    ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("writer"), ts.factory.createIdentifier(`write${field.toBinaryMethodName(valueDescriptor, rootDescriptor)}`)), undefined, valueExprArgs)),
                ], true)),
            ]));
            statements.push(ts.factory.createForOfStatement(undefined, ts.factory.createVariableDeclarationList([
                ts.factory.createVariableDeclaration(ts.factory.createArrayBindingPattern([
                    ts.factory.createBindingElement(undefined, undefined, "key"),
                    ts.factory.createBindingElement(undefined, undefined, "value"),
                ])),
            ], ts.NodeFlags.Const), propAccessor, ts.factory.createBlock([writeCall])));
        }
        else {
            const propParameters = [
                ts.factory.createNumericLiteral(fieldDescriptor.number),
                propAccessor,
            ];
            if (field.isMessage(fieldDescriptor)) {
                if (field.isRepeated(fieldDescriptor)) {
                    propParameters.push(ts.factory.createArrowFunction(undefined, undefined, [
                        ts.factory.createParameterDeclaration(undefined, undefined, "item", undefined, type.getTypeReference(rootDescriptor, fieldDescriptor.type_name)),
                    ], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("item"), "serialize"), undefined, [ts.factory.createIdentifier("writer")])));
                }
                else {
                    propParameters.push(ts.factory.createArrowFunction(undefined, undefined, [], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(ts.factory.createThis(), getFieldName(fieldDescriptor)), "serialize"), undefined, [ts.factory.createIdentifier("writer")])));
                }
            }
            let condition;
            if (rootDescriptor.syntax == "proto3" &&
                !fieldDescriptor.proto3_optional &&
                !field.isMessage(fieldDescriptor) &&
                !field.isBytes(fieldDescriptor) &&
                !fieldDescriptor.has_oneof_index) {
                if (field.hasJsTypeString(fieldDescriptor)) {
                    condition = ts.factory.createBinaryExpression(propAccessor, ts.factory.createToken(ts.SyntaxKind.ExclamationEqualsToken), ts.factory.createStringLiteral("0"));
                }
                else if (field.isEnum(fieldDescriptor)) {
                    condition = ts.factory.createBinaryExpression(propAccessor, ts.factory.createToken(ts.SyntaxKind.ExclamationEqualsToken), ts.factory.createPropertyAccessExpression(type.getTypeReferenceExpr(rootDescriptor, fieldDescriptor.type_name), type.getLeadingEnumMember(fieldDescriptor.type_name)));
                }
                else if (field.isBoolean(fieldDescriptor)) {
                    condition = ts.factory.createBinaryExpression(propAccessor, ts.factory.createToken(ts.SyntaxKind.ExclamationEqualsToken), ts.factory.createFalse());
                }
                else {
                    condition = ts.factory.createBinaryExpression(propAccessor, ts.factory.createToken(ts.SyntaxKind.ExclamationEqualsToken), ts.factory.createNumericLiteral(0));
                }
            }
            else {
                condition = hasFieldCondition;
            }
            const statement = ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("writer"), ts.factory.createIdentifier(`write${field.toBinaryMethodName(fieldDescriptor, rootDescriptor)}`)), undefined, propParameters));
            if (field.isRepeated(fieldDescriptor)) {
                condition = ts.factory.createPropertyAccessExpression(propAccessor, "length");
            }
            else if ((field.isString(fieldDescriptor) || field.isBytes(fieldDescriptor)) &&
                !fieldDescriptor.has_oneof_index) {
                condition = hasFieldCondition
                    ? ts.factory.createBinaryExpression(hasFieldCondition, ts.factory.createToken(ts.SyntaxKind.AmpersandAmpersandToken), ts.factory.createPropertyAccessExpression(propAccessor, "length"))
                    : ts.factory.createPropertyAccessExpression(propAccessor, "length");
            }
            statements.push(condition ? ts.factory.createIfStatement(condition, statement) : statement);
        }
    }
    statements.push(ts.factory.createIfStatement(ts.factory.createPrefixUnaryExpression(ts.SyntaxKind.ExclamationToken, ts.factory.createIdentifier("w")), ts.factory.createReturnStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("writer"), "getResultBuffer"), undefined, []))));
    return [
        ts.factory.createMethodDeclaration(undefined, undefined, "serialize", undefined, undefined, [], ts.factory.createTypeReferenceNode("Uint8Array"), undefined),
        ts.factory.createMethodDeclaration(undefined, undefined, "serialize", undefined, undefined, [
            ts.factory.createParameterDeclaration(undefined, undefined, "w", undefined, ts.factory.createTypeReferenceNode(ts.factory.createQualifiedName(pbIdentifier, "BinaryWriter")), undefined),
        ], ts.factory.createTypeReferenceNode("void"), undefined),
        ts.factory.createMethodDeclaration(undefined, undefined, "serialize", undefined, undefined, [
            ts.factory.createParameterDeclaration(undefined, undefined, "w", ts.factory.createToken(ts.SyntaxKind.QuestionToken), ts.factory.createTypeReferenceNode(ts.factory.createQualifiedName(pbIdentifier, "BinaryWriter")), undefined),
        ], ts.factory.createUnionTypeNode([
            ts.factory.createTypeReferenceNode("Uint8Array"),
            ts.factory.createTypeReferenceNode("void"),
        ]), ts.factory.createBlock(statements, true)),
    ];
}
/**
 * Returns the deserialize method for the message class
 */
function createDeserialize(rootDescriptor, messageDescriptor, pbIdentifier, parentName = '') {
    const statements = [
        ts.factory.createVariableStatement(undefined, ts.factory.createVariableDeclarationList([
            ts.factory.createVariableDeclaration("reader", undefined, undefined, ts.factory.createConditionalExpression(ts.factory.createBinaryExpression(ts.factory.createIdentifier("bytes"), ts.SyntaxKind.InstanceOfKeyword, ts.factory.createPropertyAccessExpression(pbIdentifier, "BinaryReader")), ts.factory.createToken(ts.SyntaxKind.QuestionToken), ts.factory.createIdentifier("bytes"), ts.factory.createToken(ts.SyntaxKind.ColonToken), ts.factory.createNewExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "BinaryReader"), undefined, [ts.factory.createIdentifier("bytes")]))),
            ts.factory.createVariableDeclaration("message", undefined, undefined, ts.factory.createNewExpression(ts.factory.createIdentifier(`${parentName}${messageDescriptor.name}`), undefined, [])),
        ], ts.NodeFlags.Const)),
    ];
    const cases = [];
    for (const fieldDescriptor of messageDescriptor.field) {
        const statements = [];
        if (field.isRepeated(fieldDescriptor) &&
            !field.isMessage(fieldDescriptor) &&
            !field.isPacked(rootDescriptor, fieldDescriptor)) {
            statements.push(ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "Message"), "addToRepeatedField"), undefined, [
                ts.factory.createIdentifier("message"),
                ts.factory.createNumericLiteral(fieldDescriptor.number),
                ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), `read${field.toBinaryMethodName(fieldDescriptor, rootDescriptor, false)}`), undefined, []),
            ])));
        }
        else if (field.isMap(fieldDescriptor)) {
            const [keyDescriptor, valueDescriptor] = type.getMapDescriptor(fieldDescriptor.type_name).field;
            const keyCall = ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), ts.factory.createIdentifier(`read${field.toBinaryMethodName(keyDescriptor, rootDescriptor)}`));
            let valueCall;
            if (field.isMessage(valueDescriptor)) {
                valueCall = ts.factory.createArrowFunction(undefined, undefined, [], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createBlock([
                    ts.factory.createVariableStatement(undefined, ts.factory.createVariableDeclarationList([ts.factory.createVariableDeclaration("value")], ts.NodeFlags.Let)),
                    ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), "readMessage"), undefined, [
                        ts.factory.createIdentifier("message"),
                        ts.factory.createArrowFunction(undefined, undefined, [], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createBinaryExpression(ts.factory.createIdentifier("value"), ts.SyntaxKind.EqualsToken, ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(type.getTypeReferenceExpr(rootDescriptor, valueDescriptor.type_name), "deserialize"), undefined, [ts.factory.createIdentifier("reader")]))),
                    ])),
                    ts.factory.createReturnStatement(ts.factory.createIdentifier("value")),
                ], true));
            }
            else {
                valueCall = ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), ts.factory.createIdentifier(`read${field.toBinaryMethodName(valueDescriptor, rootDescriptor)}`));
            }
            statements.push(ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), "readMessage"), undefined, [
                ts.factory.createIdentifier("message"),
                ts.factory.createArrowFunction(undefined, undefined, [], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "Map"), "deserializeBinary"), undefined, [
                    ts.factory.createAsExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("message"), getFieldName(fieldDescriptor)), ts.factory.createToken(ts.SyntaxKind.AnyKeyword)),
                    ts.factory.createIdentifier("reader"),
                    keyCall,
                    valueCall,
                ])),
            ])));
        }
        else if (field.isMessage(fieldDescriptor)) {
            const readCall = ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(type.getTypeReferenceExpr(rootDescriptor, fieldDescriptor.type_name), "deserialize"), undefined, [ts.factory.createIdentifier("reader")]);
            statements.push(ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), "readMessage"), undefined, [
                ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("message"), getFieldName(fieldDescriptor)),
                ts.factory.createArrowFunction(undefined, undefined, [], undefined, ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken), field.isRepeated(fieldDescriptor)
                    ? ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createPropertyAccessExpression(pbIdentifier, "Message"), "addToRepeatedWrapperField"), undefined, [
                        ts.factory.createIdentifier("message"),
                        ts.factory.createNumericLiteral(fieldDescriptor.number),
                        readCall,
                        type.getTypeReferenceExpr(rootDescriptor, fieldDescriptor.type_name),
                    ])
                    : ts.factory.createBinaryExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("message"), getFieldName(fieldDescriptor)), ts.SyntaxKind.EqualsToken, readCall)),
            ])));
        }
        else {
            statements.push(ts.factory.createExpressionStatement(ts.factory.createBinaryExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("message"), getFieldName(fieldDescriptor)), ts.SyntaxKind.EqualsToken, ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), `read${field.toBinaryMethodName(fieldDescriptor, rootDescriptor, false)}`), undefined, undefined))));
        }
        statements.push(ts.factory.createBreakStatement());
        cases.push(ts.factory.createCaseClause(ts.factory.createNumericLiteral(fieldDescriptor.number), statements));
    }
    // Default clause
    cases.push(ts.factory.createDefaultClause([
        ts.factory.createExpressionStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), "skipField"), undefined, [])),
    ]));
    statements.push(ts.factory.createWhileStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), "nextField"), undefined, []), ts.factory.createBlock([
        ts.factory.createIfStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), "isEndGroup"), undefined, undefined), ts.factory.createBreakStatement()),
        ts.factory.createSwitchStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier("reader"), "getFieldNumber"), undefined, []), ts.factory.createCaseBlock(cases)),
    ], true)));
    statements.push(ts.factory.createReturnStatement(ts.factory.createIdentifier("message")));
    return ts.factory.createMethodDeclaration([ts.factory.createModifier(ts.SyntaxKind.StaticKeyword)], undefined, ts.factory.createIdentifier("deserialize"), undefined, undefined, [
        ts.factory.createParameterDeclaration(undefined, undefined, ts.factory.createIdentifier("bytes"), undefined, ts.factory.createUnionTypeNode([
            ts.factory.createTypeReferenceNode(ts.factory.createIdentifier("Uint8Array"), undefined),
            ts.factory.createTypeReferenceNode(ts.factory.createQualifiedName(pbIdentifier, "BinaryReader"), undefined),
        ])),
    ], ts.factory.createTypeReferenceNode(`${parentName}${messageDescriptor.name}`, undefined), ts.factory.createBlock(statements, true));
}
/**
 * Returns the deserializeBinary method for the message class
 */
function createDeserializeBinary(messageDescriptor, parentName = '') {
    const modifiers = [
        ts.factory.createModifier(ts.SyntaxKind.StaticKeyword)
    ];
    if (config.explicit_override) {
        modifiers.push(ts.factory.createModifier(ts.SyntaxKind.OverrideKeyword));
    }
    return ts.factory.createMethodDeclaration(modifiers, undefined, ts.factory.createIdentifier("deserializeBinary"), undefined, undefined, [
        ts.factory.createParameterDeclaration(undefined, undefined, ts.factory.createIdentifier("bytes"), undefined, ts.factory.createTypeReferenceNode(ts.factory.createIdentifier("Uint8Array"))),
    ], ts.factory.createTypeReferenceNode(`${parentName}${messageDescriptor.name}`), ts.factory.createBlock([
        ts.factory.createReturnStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createIdentifier(`${parentName}${messageDescriptor.name}`), "deserialize"), undefined, [ts.factory.createIdentifier("bytes")])),
    ], true));
}
/**
 * Returns the serializeBinary method for the Message class
 */
function createSerializeBinary() {
    return ts.factory.createMethodDeclaration(undefined, undefined, ts.factory.createIdentifier("serializeBinary"), undefined, undefined, [], ts.factory.createUnionTypeNode([
        ts.factory.createTypeReferenceNode(ts.factory.createIdentifier("Uint8Array"), []),
    ]), ts.factory.createBlock([
        ts.factory.createReturnStatement(ts.factory.createCallExpression(ts.factory.createPropertyAccessExpression(ts.factory.createThis(), "serialize"), undefined, undefined)),
    ], true));
}
function createOneOfDecls(messageDescriptor) {
    var _a;
    const declMap = new Array(messageDescriptor.oneof_decl.length);
    for (const field of messageDescriptor.field) {
        if (field.has_oneof_index) {
            declMap[_a = field.oneof_index] ?? (declMap[_a] = []);
            declMap[field.oneof_index].push(ts.factory.createNumericLiteral(field.number));
        }
    }
    const decls = [];
    for (const map of declMap) {
        decls.push(ts.factory.createArrayLiteralExpression(map));
    }
    return ts.factory.createPropertyDeclaration([], ts.factory.createPrivateIdentifier("#one_of_decls"), undefined, ts.factory.createArrayTypeNode(ts.factory.createArrayTypeNode(ts.factory.createKeywordTypeNode(ts.SyntaxKind.NumberKeyword))), ts.factory.createArrayLiteralExpression(decls));
}
/**
 * Returns a class for the message descriptor
 */
function createMessage(rootDescriptor, messageDescriptor, pbIdentifier, parentName) {
    const statements = [
        createOneOfDecls(messageDescriptor),
        // Create constructor
        createConstructor(rootDescriptor, messageDescriptor, pbIdentifier, parentName),
    ];
    for (const fieldDescriptor of messageDescriptor.field) {
        statements.push(createGetter(rootDescriptor, fieldDescriptor, pbIdentifier));
        statements.push(createSetter(rootDescriptor, messageDescriptor, fieldDescriptor, pbIdentifier));
        if (field.hasPresenceGetter(rootDescriptor, fieldDescriptor)) {
            statements.push(createPresenceHas(fieldDescriptor, pbIdentifier));
        }
    }
    for (const [index, oneof] of messageDescriptor.oneof_decl.entries()) {
        // Create one of getters
        statements.push(createOneOfGetter(index, oneof, messageDescriptor, pbIdentifier));
    }
    statements.push(
    // Create fromObject method
    createFromObject(rootDescriptor, messageDescriptor, parentName), 
    // Create toObject method
    createToObject(rootDescriptor, messageDescriptor));
    statements.push(
    // Create serialize  method
    ...createSerialize(rootDescriptor, messageDescriptor, pbIdentifier), 
    // Create deserialize method
    createDeserialize(rootDescriptor, messageDescriptor, pbIdentifier, parentName), 
    // Create serializeBinary method
    createSerializeBinary(), 
    // Create deserializeBinary method
    createDeserializeBinary(messageDescriptor, parentName));
    // Create message class
    return comment.addDeprecatedJsDoc(ts.factory.createClassDeclaration([ts.factory.createModifier(ts.SyntaxKind.ExportKeyword)], `${parentName}${messageDescriptor.name}`, undefined, [
        ts.factory.createHeritageClause(ts.SyntaxKind.ExtendsKeyword, [
            ts.factory.createExpressionWithTypeArguments(ts.factory.createPropertyAccessExpression(pbIdentifier, ts.factory.createIdentifier("Message")), []),
        ]),
    ], statements), messageDescriptor.options?.deprecated);
}
function processDescriptorRecursively(rootDescriptor, descriptor, pbIdentifier, no_namespace, parentName = '') {
    const statements = [
        createMessage(rootDescriptor, descriptor, pbIdentifier, parentName),
    ];
    const namespacedStatements = [];
    for (const _enum of descriptor.enum_type) {
        if (no_namespace) {
            statements.push(createEnum(_enum, `${parentName}${descriptor.name}`));
        }
        else {
            namespacedStatements.push(createEnum(_enum));
        }
    }
    for (const message of descriptor.nested_type) {
        if (no_namespace) {
            statements.push(...processDescriptorRecursively(rootDescriptor, message, pbIdentifier, no_namespace, `${parentName}${descriptor.name}`));
        }
        else {
            namespacedStatements.push(...processDescriptorRecursively(rootDescriptor, message, pbIdentifier, no_namespace));
        }
    }
    if (namespacedStatements.length) {
        statements.push(createNamespace(descriptor.name, namespacedStatements));
    }
    return statements;
}
exports.processDescriptorRecursively = processDescriptorRecursively;
