"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.preprocess = exports.getTypeReference = exports.getTypeReferenceExpr = exports.getLeadingEnumMember = exports.getMapDescriptor = exports.setIdentifierForDependency = exports.resetDependencyMap = exports.initialize = void 0;
const descriptor = require("./compiler/descriptor.js");
const ts = require("typescript");
const symbolMap = new Map();
const dependencyMap = new Map();
const mapMap = new Map();
const enumLeadingMemberMap = new Map();
const packages = [];
let config;
function initialize(configParameters) {
    config = configParameters;
}
exports.initialize = initialize;
function resetDependencyMap() {
    dependencyMap.clear();
}
exports.resetDependencyMap = resetDependencyMap;
function setIdentifierForDependency(dependency, identifier) {
    dependencyMap.set(dependency, identifier);
}
exports.setIdentifierForDependency = setIdentifierForDependency;
function isMapEntry(descriptor) {
    return descriptor?.options?.map_entry ?? false;
}
function getMapDescriptor(typeName) {
    return mapMap.get(typeName);
}
exports.getMapDescriptor = getMapDescriptor;
function getLeadingEnumMember(type_name) {
    return enumLeadingMemberMap.get(type_name);
}
exports.getLeadingEnumMember = getLeadingEnumMember;
function getTypeReferenceExpr(rootDescriptor, typeName) {
    const path = symbolMap.get(typeName);
    if (!path || !dependencyMap.has(path)) {
        if (config.no_namespace) {
            return ts.factory.createIdentifier(removeRootParentName(typeName, rootDescriptor.package).replace(/\./g, ''));
        }
        return ts.factory.createIdentifier(removeRootParentName(typeName, rootDescriptor.package));
    }
    // const name = removeNamespace(removeLeadingDot(typeName));
    const segs = typeName.split(".");
    const name = segs.filter(s => s.length && isUppercase(s)).join('');
    return ts.factory.createPropertyAccessExpression(dependencyMap.get(path), name);
}
exports.getTypeReferenceExpr = getTypeReferenceExpr;
function getTypeReference(rootDescriptor, typeName) {
    const path = symbolMap.get(typeName);
    if (!path || !dependencyMap.has(path)) {
        if (config.no_namespace) {
            return ts.factory.createTypeReferenceNode(removeRootParentName(typeName, rootDescriptor.package).replace(/\./g, ''));
        }
        return ts.factory.createTypeReferenceNode(removeRootParentName(typeName, rootDescriptor.package));
    }
    const segs = typeName.split(".");
    const name = segs.filter(s => s.length && isUppercase(s)).join('');
    return ts.factory.createTypeReferenceNode(ts.factory.createQualifiedName(dependencyMap.get(path), name));
}
exports.getTypeReference = getTypeReference;
function isUppercase(word) {
    return word[0] !== word[0].toLowerCase();
}
function removeLeadingDot(name) {
    return name.replace(/^\./, "");
}
function replaceDoubleDots(name) {
    return name.replace(/\.\./g, ".");
}
function removeRootParentName(name, parentName) {
    return removeLeadingDot(parentName ? name.replace(`${parentName}.`, "") : name);
}
function removeNamespace(name) {
    return removeRootParentName(name, packages.find(p => name.startsWith(p))).replace(/\./g, '');
}
function preprocess(targetDescriptor, path, prefix) {
    if (targetDescriptor instanceof descriptor.FileDescriptorProto) {
        packages.push(targetDescriptor.package);
    }
    for (const enumDescriptor of targetDescriptor.enum_type) {
        const name = replaceDoubleDots(`${prefix}.${enumDescriptor.name}`);
        symbolMap.set(name, path);
        enumLeadingMemberMap.set(name, enumDescriptor.value[0].name);
    }
    const messages = targetDescriptor instanceof descriptor.FileDescriptorProto
        ? targetDescriptor.message_type
        : targetDescriptor.nested_type;
    for (let index = messages.length - 1; index >= 0; index--) {
        const messageDescriptor = messages[index];
        const name = replaceDoubleDots(`${prefix}.${messageDescriptor.name}`);
        if (isMapEntry(messageDescriptor)) {
            mapMap.set(name, messageDescriptor);
            messages.splice(index, 1);
            continue;
        }
        symbolMap.set(name, path);
        preprocess(messageDescriptor, path, name);
    }
}
exports.preprocess = preprocess;
