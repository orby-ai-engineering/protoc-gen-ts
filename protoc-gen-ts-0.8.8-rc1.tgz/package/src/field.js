"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hasPresenceGetter = exports.isPacked = exports.isPackable = exports.isTypePackable = exports.isBoolean = exports.isBytes = exports.isString = exports.isRequiredWithoutExplicitDefault = exports.isOptional = exports.isEnum = exports.isNumber = exports.isMessage = exports.isRepeated = exports.isMap = exports.hasJsTypeString = exports.toBinaryMethodName = exports.getType = exports.getMapType = exports.wrapRepeatedType = void 0;
const descriptor = require("./compiler/descriptor.js");
const type = require("./type.js");
const ts = require("typescript");
/**
 * @param {*} type
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function wrapRepeatedType(type, fieldDescriptor) {
    if (isRepeated(fieldDescriptor) && !isMap(fieldDescriptor)) {
        type = ts.factory.createArrayTypeNode(type);
    }
    return type;
}
exports.wrapRepeatedType = wrapRepeatedType;
/**
 * @param {descriptor.FileDescriptorProto} rootDescriptor
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function getMapType(rootDescriptor, fieldDescriptor) {
    const messageDescriptor = type.getMapDescriptor(fieldDescriptor.type_name);
    const [keyDescriptor, valueDescriptor] = messageDescriptor.field;
    return ts.factory.createTypeReferenceNode("Map", [
        getType(keyDescriptor, rootDescriptor),
        getType(valueDescriptor, rootDescriptor),
    ]);
}
exports.getMapType = getMapType;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 * @param {descriptor.FileDescriptorProto} rootDescriptor
 * @returns {ts.TypeReferenceNode | ts.Identifier | ts.PropertyAccessExpression}
 */
function getType(fieldDescriptor, rootDescriptor) {
    if (isMap(fieldDescriptor)) {
        return getMapType(rootDescriptor, fieldDescriptor);
    }
    else if (hasJsTypeString(fieldDescriptor)) {
        return ts.factory.createTypeReferenceNode("string");
    }
    switch (fieldDescriptor.type) {
        case descriptor.FieldDescriptorProto.Type.TYPE_DOUBLE:
        case descriptor.FieldDescriptorProto.Type.TYPE_FLOAT:
        case descriptor.FieldDescriptorProto.Type.TYPE_INT32:
        case descriptor.FieldDescriptorProto.Type.TYPE_INT64:
        case descriptor.FieldDescriptorProto.Type.TYPE_UINT32:
        case descriptor.FieldDescriptorProto.Type.TYPE_UINT64:
        case descriptor.FieldDescriptorProto.Type.TYPE_SINT32:
        case descriptor.FieldDescriptorProto.Type.TYPE_SINT64:
        case descriptor.FieldDescriptorProto.Type.TYPE_FIXED32:
        case descriptor.FieldDescriptorProto.Type.TYPE_FIXED64:
        case descriptor.FieldDescriptorProto.Type.TYPE_SFIXED32:
        case descriptor.FieldDescriptorProto.Type.TYPE_SFIXED64:
        case descriptor.FieldDescriptorProto.Type.TYPE_SFIXED64:
            return ts.factory.createTypeReferenceNode("number");
        case descriptor.FieldDescriptorProto.Type.TYPE_STRING:
            return ts.factory.createTypeReferenceNode("string");
        case descriptor.FieldDescriptorProto.Type.TYPE_BOOL:
            return ts.factory.createTypeReferenceNode("boolean");
        case descriptor.FieldDescriptorProto.Type.TYPE_BYTES:
            return ts.factory.createTypeReferenceNode("Uint8Array");
        case descriptor.FieldDescriptorProto.Type.TYPE_MESSAGE:
        case descriptor.FieldDescriptorProto.Type.TYPE_ENUM:
            return type.getTypeReference(rootDescriptor, fieldDescriptor.type_name);
        default:
            throw new Error("Unhandled type " + fieldDescriptor.type);
    }
}
exports.getType = getType;
/**
 * @param {descriptor.FileDescriptorProto} rootDescriptor
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function toBinaryMethodName(fieldDescriptor, rootDescriptor, isWriter = true) {
    const typeNames = Object.keys(descriptor.FieldDescriptorProto.Type)
        .map((key) => descriptor.FieldDescriptorProto.Type[+key])
        .filter((n) => typeof n == "string")
        .map((n) => n.replace("TYPE_", ""));
    let typeName = typeNames[fieldDescriptor.type - 1].toLowerCase();
    //lowercase first char
    typeName = typeName.charAt(0).toUpperCase() + typeName.slice(1);
    const suffix = hasJsTypeString(fieldDescriptor) ? "String" : "";
    if (isPacked(rootDescriptor, fieldDescriptor)) {
        return `Packed${typeName}${suffix}`;
    }
    else {
        if (isRepeated(fieldDescriptor) && isWriter) {
            return `Repeated${typeName}${suffix}`;
        }
        else {
            return `${typeName}${suffix}`;
        }
    }
}
exports.toBinaryMethodName = toBinaryMethodName;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function hasJsTypeString(fieldDescriptor) {
    return (fieldDescriptor.options &&
        fieldDescriptor.options.jstype == descriptor.FieldOptions.JSType.JS_STRING);
}
exports.hasJsTypeString = hasJsTypeString;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isMap(fieldDescriptor) {
    return type.getMapDescriptor(fieldDescriptor.type_name) != undefined;
}
exports.isMap = isMap;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isRepeated(fieldDescriptor) {
    return (fieldDescriptor.label ==
        descriptor.FieldDescriptorProto.Label.LABEL_REPEATED);
}
exports.isRepeated = isRepeated;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isMessage(fieldDescriptor) {
    return (fieldDescriptor.type == descriptor.FieldDescriptorProto.Type.TYPE_MESSAGE);
}
exports.isMessage = isMessage;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isNumber(fieldDescriptor) {
    switch (fieldDescriptor.type) {
        case descriptor.FieldDescriptorProto.Type.TYPE_DOUBLE:
        case descriptor.FieldDescriptorProto.Type.TYPE_FLOAT:
        case descriptor.FieldDescriptorProto.Type.TYPE_INT32:
        case descriptor.FieldDescriptorProto.Type.TYPE_INT64:
        case descriptor.FieldDescriptorProto.Type.TYPE_UINT32:
        case descriptor.FieldDescriptorProto.Type.TYPE_UINT64:
        case descriptor.FieldDescriptorProto.Type.TYPE_SINT32:
        case descriptor.FieldDescriptorProto.Type.TYPE_SINT64:
        case descriptor.FieldDescriptorProto.Type.TYPE_FIXED32:
        case descriptor.FieldDescriptorProto.Type.TYPE_FIXED64:
        case descriptor.FieldDescriptorProto.Type.TYPE_SFIXED32:
        case descriptor.FieldDescriptorProto.Type.TYPE_SFIXED64:
        case descriptor.FieldDescriptorProto.Type.TYPE_SFIXED64:
            return true;
        default:
            return false;
    }
}
exports.isNumber = isNumber;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isEnum(fieldDescriptor) {
    return fieldDescriptor.type == descriptor.FieldDescriptorProto.Type.TYPE_ENUM;
}
exports.isEnum = isEnum;
/**
 * @param {descriptor.FileDescriptorProto} rootDescriptor
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isOptional(rootDescriptor, fieldDescriptor) {
    if (rootDescriptor.syntax == "proto3") {
        return (fieldDescriptor.label !=
            descriptor.FieldDescriptorProto.Label.LABEL_REQUIRED ||
            fieldDescriptor.proto3_optional);
    }
    return (fieldDescriptor.label ==
        descriptor.FieldDescriptorProto.Label.LABEL_OPTIONAL);
}
exports.isOptional = isOptional;
/**
 * @param {descriptor.FileDescriptorProto} rootDescriptor
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isRequiredWithoutExplicitDefault(rootDescriptor, fieldDescriptor) {
    return (rootDescriptor.syntax != "proto3" &&
        fieldDescriptor.label == descriptor.FieldDescriptorProto.Label.LABEL_REQUIRED &&
        !fieldDescriptor.has_default_value);
}
exports.isRequiredWithoutExplicitDefault = isRequiredWithoutExplicitDefault;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isString(fieldDescriptor) {
    return (fieldDescriptor.type == descriptor.FieldDescriptorProto.Type.TYPE_STRING);
}
exports.isString = isString;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isBytes(fieldDescriptor) {
    return (fieldDescriptor.type == descriptor.FieldDescriptorProto.Type.TYPE_BYTES);
}
exports.isBytes = isBytes;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function isBoolean(fieldDescriptor) {
    return fieldDescriptor.type == descriptor.FieldDescriptorProto.Type.TYPE_BOOL;
}
exports.isBoolean = isBoolean;
/**
 *
 * @param {descriptor.FieldDescriptorProto.Type} type
 * @see https://github.com/protocolbuffers/protobuf/blob/ef8d418fad8366f9854127eb4338b0757eda9aa3/src/google/protobuf/descriptor.h#L2392
 */
function isTypePackable(type) {
    return (type != descriptor.FieldDescriptorProto.Type.TYPE_STRING &&
        type != descriptor.FieldDescriptorProto.Type.TYPE_GROUP &&
        type != descriptor.FieldDescriptorProto.Type.TYPE_MESSAGE &&
        type != descriptor.FieldDescriptorProto.Type.TYPE_BYTES);
}
exports.isTypePackable = isTypePackable;
/**
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 * @see https://github.com/protocolbuffers/protobuf/blob/ef8d418fad8366f9854127eb4338b0757eda9aa3/src/google/protobuf/descriptor.h#L2283
 */
function isPackable(fieldDescriptor) {
    return isRepeated(fieldDescriptor) && isTypePackable(fieldDescriptor.type);
}
exports.isPackable = isPackable;
function isPacked(rootDescriptor, fieldDescriptor) {
    if (!isPackable(fieldDescriptor))
        return false;
    const options = fieldDescriptor.options;
    // weirdly the compiler does not send the syntax information
    // it only sends when the syntax is proto3 so we have to look for it.
    // when it is empty, it indicates that the syntax is proto2 for sure
    if (rootDescriptor.syntax == "proto3") {
        return !options || !options.has_packed || options.packed;
    }
    return options != null && options.packed;
}
exports.isPacked = isPacked;
/**
 * @param {descriptor.FileDescriptorProto} rootDescriptor
 * @param {descriptor.FieldDescriptorProto} fieldDescriptor
 */
function hasPresenceGetter(rootDescriptor, fieldDescriptor) {
    return (!isRepeated(fieldDescriptor) &&
        !isMap(fieldDescriptor) &&
        !(rootDescriptor.syntax == "proto3" &&
            !(fieldDescriptor.proto3_optional || isMessage(fieldDescriptor) || fieldDescriptor.has_oneof_index)));
}
exports.hasPresenceGetter = hasPresenceGetter;
