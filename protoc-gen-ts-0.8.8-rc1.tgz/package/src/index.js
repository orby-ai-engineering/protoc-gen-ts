"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ts = require("typescript");
const path = require("path");
const fs = require("fs");
const plugin = require("./compiler/plugin");
const type = require("./type");
const descriptor = require("./descriptor");
const op = require("./option");
const rpc_node = require("./rpc/node");
const rpc_web = require("./rpc/web");
const rpc_server = require("./rpc/server");
function createImport(identifier, moduleSpecifier) {
    return ts.factory.createImportDeclaration(undefined, ts.factory.createImportClause(false, ts.factory.createNamespaceImport(identifier), undefined), ts.factory.createStringLiteral(moduleSpecifier));
}
function replaceExtension(filename, extension = ".ts") {
    return filename.replace(/\.[^/.]+$/, extension);
}
const request = plugin.CodeGeneratorRequest.deserialize(new Uint8Array(fs.readFileSync(process.stdin.fd)));
const response = new plugin.CodeGeneratorResponse({
    supported_features: plugin.CodeGeneratorResponse.Feature.FEATURE_PROTO3_OPTIONAL,
    file: [],
});
const [tsVersionMajor, tsVersionMinor] = ts.version.split(".").map(Number);
if (!(tsVersionMajor >= 4 && tsVersionMinor >= 9)) {
    response.error = "protoc-gen-ts requires TypeScript 4.9 or above.";
    process.stdout.write(response.serialize());
    // will help to flush the stdout buffer.
    process.stdout.write(new Uint8Array());
    process.exit();
}
const options = op.parse(request.parameter);
type.initialize(options);
descriptor.initialize(options);
for (const fileDescriptor of request.proto_file) {
    type.preprocess(fileDescriptor, fileDescriptor.name, `.${fileDescriptor.package ?? ""}`);
}
for (const fileDescriptor of request.proto_file) {
    const name = replaceExtension(fileDescriptor.name);
    const pbIdentifier = ts.factory.createUniqueName("pb");
    const grpcIdentifier = ts.factory.createUniqueName("grpc");
    const grpcWebIdentifier = ts.factory.createUniqueName("grpc_web");
    // Will keep track of import statements
    const importStatements = [
        // Create all named imports from dependencies
        ...fileDescriptor.dependency.map((dependency) => {
            const identifier = ts.factory.createUniqueName(`dependency`);
            const moduleSpecifier = replaceExtension(dependency, "");
            type.setIdentifierForDependency(dependency, identifier);
            return createImport(identifier, `./${path.relative(path.dirname(fileDescriptor.name), moduleSpecifier)}`);
        }),
    ];
    // Create all messages recursively
    let statements = [
        // Process enums
        ...fileDescriptor.enum_type.map((enumDescriptor) => descriptor.createEnum(enumDescriptor)),
        // Process root messages
        ...fileDescriptor.message_type.flatMap((messageDescriptor) => descriptor.processDescriptorRecursively(fileDescriptor, messageDescriptor, pbIdentifier, options.no_namespace)),
    ];
    if (statements.length) {
        importStatements.push(createImport(pbIdentifier, "google-protobuf"));
    }
    if (!options.no_grpc && fileDescriptor.service.length) {
        // Import grpc only if there is service statements
        // importStatements.push(createImport(grpcIdentifier, options.grpc_package));
        if (options.target != "web") {
            statements.push(...rpc_server.createGrpcInterfaceType(grpcIdentifier));
        }
        else {
            // import grc-web when the target is web
            importStatements.push(createImport(grpcWebIdentifier, "grpc-web"));
        }
        // Create all services and clients
        for (const serviceDescriptor of fileDescriptor.service) {
            // target: node server
            // statements.push(
            //   rpc_server.createUnimplementedServer(
            //     fileDescriptor,
            //     serviceDescriptor,
            //     grpcIdentifier,
            //   ),
            // );
            // target: web via grpc-web
            if (options.target == "web") {
                statements.push(rpc_web.createServiceClient(fileDescriptor, serviceDescriptor, grpcWebIdentifier, options));
            }
            else {
                // target: node via @grpc/grpc-js or grpc (deprecated)
                statements.push(rpc_node.createServiceClient(fileDescriptor, serviceDescriptor, grpcIdentifier, options));
            }
        }
    }
    const { major = 0, minor = 0, patch = 0 } = request.compiler_version ?? {};
    const comments = [
        `Generateddd by the protoc-gen-ts.  DO NOT EDIT!`,
        `compiler version: ${major}.${minor}.${patch}`,
        `source: ${fileDescriptor.name}`,
        `git: https://github.com/thesayyn/protoc-gen-ts`,
        //`target: ${options.target}`
    ];
    if (fileDescriptor.options?.deprecated) {
        comments.push("@deprecated");
    }
    const doNotEditComment = ts.factory.createJSDocComment(comments.join("\n"));
    // Wrap statements within the namespace
    if (fileDescriptor.package && !options.no_namespace) {
        statements = [
            doNotEditComment,
            ...importStatements,
            descriptor.createNamespace(fileDescriptor.package, statements),
        ];
    }
    else {
        statements = [doNotEditComment, ...importStatements, ...statements];
    }
    const sourcefile = ts.factory.createSourceFile(statements, ts.factory.createToken(ts.SyntaxKind.EndOfFileToken), ts.NodeFlags.None);
    // @ts-ignore
    sourcefile.identifiers = new Set();
    const content = ts
        .createPrinter({
        newLine: ts.NewLineKind.LineFeed,
        omitTrailingSemicolon: true,
    })
        .printFile(sourcefile);
    response.file.push(new plugin.CodeGeneratorResponse.File({
        name,
        content,
    }));
    // after each iteration we need to clear the dependency map to prevent accidental
    // misuse of identifiers
    type.resetDependencyMap();
}
process.stdout.write(response.serialize());
